create database recuperacao;
use recuperacao;

create table nivelAcesso(
	id bigint not null auto_increment,
    nivel varchar(100) not null,
    descricao varchar(200),
    primary key(id)
);

insert into nivelAcesso (nivel,descricao) values 
('Admin','blablá'),('Gestor','blablá'),
('Usuário','blablá'),('Visitante','blablá');

create table ocupacao(
	id bigint not null auto_increment,
    titulo varchar(150) not null,
    nivelAcessoFk bigint not null,
    primary key(id),
    foreign key(nivelAcessoFk) references nivelAcesso(id)
);

insert into ocupacao (titulo,nivelAcessoFk) values 
('Professor',3),('Secretaria',3),
('Coordenador',2),('Orientador',2),
('Aluno',4),('TI',1);

create table usuarios(
	id bigint not null auto_increment,
    nome varchar(150) not null,
    email varchar(150) not null,
	dataNascimento date not null,
    senha varchar(30) not null,
    dataCadastro datetime not null default now(),
    ocupacaoFk bigint not null,
    status boolean not null default true,
    img text not null,
    phoneNumber text not null,
    primary key(id),
    foreign key(ocupacaoFk) references ocupacao(id)
);

insert into usuarios (nome,email,senha,dataNascimento,ocupacaoFk,img,phoneNumber) values 
('João','joao@gmail.com','55s888ff','2000-01-01',1,"jahsjakj","19971030570"),
('Mara','mara@gmail.com','554333','1986-01-03',2,"jahsjakj","19971030570"),
('Clarice','clarice@gmail.com','54455s888ff','1999-03-01',3,"jahsjakj","19971030570"),
('Roberto','roberto@gmail.com','6666444','2001-01-21',4,"jahsjakj","19971030570"),
('Miguel','miguel@gmail.com','3354','1995-03-03',1,"jahsjakj","19971030570"),
('Lúcia','lucia@gmail.com','abbbcdd','1970-05-25',2,"jahsjakj","19971030570");


create table locais(
	id bigint not null auto_increment,
    nome varchar(150) not null,
    bloco enum('A','B','C','D') not null,
    lotacao int not null,
    primary key(id)
);

insert into locais (nome,bloco,lotacao) values 
('Laboratório Eletrônica 01','A',16),
('Auditório','C',100),
('Laboratório Eletrônica 02','B',16),
('Laboratório Mecânica 01','A',30),
('Laboratório Informática 01','D',32);

create table item(
	id bigint not null auto_increment,
    nome varchar(150) not null,    
    primary key(id)
);

insert into item (nome) values 
('Projetor'),
('Ar condicionado'),
('Lousa digital'),
('Home Theater'),
('Ipad'),
('Ferro de Solda');

create table checkList(
	id bigint not null auto_increment,
    localFk bigint not null,
    itemFk bigint not null,
    qtd int not null default 1,
    primary key(id),
    foreign key(localFk) references locais(id),
    foreign key(itemFk) references item(id)
);

insert into checkList (localFk,itemFk) values 
(1,1),(1,2),(1,5),
(2,1),(2,5),
(3,3),(3,2),
(4,1),(4,2),(4,3),(4,5);

create table eventos(
	id bigint not null auto_increment,
    nome varchar(200) not null,
    localFk bigint not null,
    inicio datetime not null,
    fim datetime not null,
    inicioCheckIn datetime not null,
    fimCheckIn datetime not null,
    vagas int not null,    
    primary key(id),
    foreign key(localFk) references locais(id)
);

insert into eventos (nome,localFk,inicio,fim,inicioCheckIn,fimCheckIn,vagas) values 
('Workshop Cloud Básico', 5,'2023-07-07 18:45:00','2023-07-07 23:10:00', '2023-06-07 18:45:00','2023-07-07 18:45:00',32),
('Desenho Técnico SolidWorks', 5,'2023-08-01 18:45:00','2023-08-02 23:10:00', '2023-06-08 18:45:00','2023-08-01 18:45:00',32),
('Ensaios Mecânicos Avançados', 4,'2023-12-01 18:45:00','2023-12-02 23:10:00', '2023-12-08 18:45:00','2023-12-01 18:45:00',30),
('Conquistando o primeiro milhão', 2,'2023-12-12 18:45:00','2023-12-12 23:10:00', '2023-12-12 18:45:00','2023-12-12 18:45:00',100);

create table checkIn(
	id bigint not null auto_increment,    
    eventoFk bigint not null,
    usuarioFk bigint not null,
    data datetime not null default now(),
    primary key(id),
    foreign key(eventoFk) references eventos(id),
    foreign key(usuarioFk) references usuarios(id)
);

insert into checkIn (eventoFk,usuarioFk) values 
(1,1), (1,2), (1,5), (2,2), (2,4), (2,5),(2,6), 
(3,1), (3,6), (4,3), (4,4), (4,5);

CREATE TABLE `status` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `tarefas` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `descricao` varchar(300) NOT NULL,
  `prazo` date NOT NULL,
  `inicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fim` datetime DEFAULT NULL,
  `localFK` bigint NOT NULL,
  `solicitanteFK` bigint NOT NULL,
  `lastStatusFK` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `localFK` (`localFK`),
  KEY `solicitanteFK` (`solicitanteFK`),
  KEY `lastStatusFK` (`lastStatusFK`),
  CONSTRAINT `tarefas_ibfk_1` FOREIGN KEY (`localFK`) REFERENCES `locais` (`id`),
  CONSTRAINT `tarefas_ibfk_2` FOREIGN KEY (`solicitanteFK`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `tarefas_ibfk_3` FOREIGN KEY (`lastStatusFK`) REFERENCES `status` (`id`)
);

CREATE TABLE `responsaveis` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `usuarioFK` bigint NOT NULL,
  `tarefaFK` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuarioFK` (`usuarioFK`),
  KEY `tarefaFK` (`tarefaFK`),
  CONSTRAINT `responsaveis_ibfk_1` FOREIGN KEY (`usuarioFK`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `responsaveis_ibfk_2` FOREIGN KEY (`tarefaFK`) REFERENCES `tarefas` (`id`)
);

CREATE TABLE `tarefastatus` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `statusFK` bigint NOT NULL,
  `tarefaFK` bigint NOT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comentario` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `statusFK` (`statusFK`),
  KEY `tarefaFK` (`tarefaFK`),
  CONSTRAINT `tarefastatus_ibfk_1` FOREIGN KEY (`statusFK`) REFERENCES `status` (`id`),
  CONSTRAINT `tarefastatus_ibfk_2` FOREIGN KEY (`tarefaFK`) REFERENCES `tarefas` (`id`)
);

CREATE TABLE `fotos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `link` varchar(300) NOT NULL,
  `tarefaStatusFK` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tarefaStatusFK` (`tarefaStatusFK`),
  CONSTRAINT `fotos_ibfk_1` FOREIGN KEY (`tarefaStatusFK`) REFERENCES `tarefastatus` (`id`)
);

create table editora(
	id bigint not null auto_increment,
    nomeEditora varchar(100) not null,
    uf varchar(2) not null,
    primary key(id)
);

insert into editora(nomeEditora,uf)values("Companhia das Letras","SP"),
("Editora Rocco","SP"),
("Editora Arqueiro","MG"),
("Ediouro","RJ"),
("Panda Books","SP"),
("Chiado Grupo Editorial","BA");

create table autor(
	id bigint not null auto_increment,
    nomeAutor varchar(100) not null,
    uf varchar(2) not null,
    primary key(id)
);

insert into autor(nomeAutor,uf)values("Clarice Lispector ","RJ"),
("Gabriel García ","SP"),
("William Shakespeare","SP"),
("Machado de Assis","MG"),
("João Cabral","BA"),
("Mario Quintana ","RS");


create table livro(
	id bigint not null auto_increment,
    nomeLivro varchar(200) not null,
    genero varchar(100) not null,
    dataPublicacao date not null,
    edicao varchar(30) not null,
    editoraFK bigint not null,
    autorFK bigint not null,
    foreign key(autorFK) references autor(id),
    foreign key(editoraFK) references editora(id),
    primary key(id)
);

insert into livro (nomeLivro, genero, dataPublicacao, edicao, editoraFK, autorFK) values
('O Sol é Para Todos', 'Drama', '2022-01-01', '1ª edição', 1, 1),
('Garota Exemplar', 'Suspense', '2022-02-02', '2ª edição', 2, 1),
('Romeu e Julieta', 'Romance', '2022-03-03', '1ª edição', 3, 3),
('A Ilha do Tesouro', 'Aventura', '2022-04-04', '3ª edição', 1, 2),
('As Vinhas da Ira', 'Drama', '2022-05-05', '2ª edição', 2, 5),
('Orgulho e Preconceito', 'Romance', '2022-06-06', '1ª edição', 3, 6),
('1984', 'Ficção Cientifica', '2022-06-06', '1ª edição', 3, 4),
('O Iluminado', 'Terror', '2022-06-06', '1ª edição', 3, 2),
('O Amor nos Tempos de Cólera', 'Romance', '2022-06-06', '1ª edição', 3, 1);

select * from livro;

create table emprestimo(
	id bigint not null auto_increment,
    dataEmprestimo date not null,
    dataEntrega date not null,
    usuarioFK bigint not null,
    responsavelFK bigint not null,
    livroFK bigint not null,
    foreign key(usuarioFK) references usuarios(id),
    foreign key(responsavelFK) references usuarios(id),
    foreign key(livroFK) references livro(id),
    primary key(id)
);

insert into emprestimo (dataEmprestimo, dataEntrega, usuarioFK, responsavelFK, livroFK) values
('2023-01-01', '2023-01-15', 1, 2, 1),
('2023-02-05', '2023-02-20', 3, 4, 2),
('2023-03-10', '2023-03-25', 2, 3, 3),
('2023-04-15', '2023-04-30', 1, 4, 4),
('2023-05-20', '2023-06-04', 5, 6, 5),
('2023-06-01', '2023-06-15', 1, 2, 2),
('2023-07-05', '2023-07-20', 3, 4, 4),
('2023-08-10', '2023-08-25', 2, 3, 3),
('2023-09-15', '2023-09-30', 1, 4, 4),
('2023-10-20', '2023-10-04', 5, 6, 5);


create table statusEmprestimo(
	id bigint not null auto_increment,
    statusEmprestimo enum('EMPRESTADO','DEVOLVIDO','FORA-DO-PRAZO') not null,
    emprestimoFK bigint not null,
    foreign key(emprestimoFK) references emprestimo(id),
    primary key(id)
);

INSERT INTO statusEmprestimo (statusEmprestimo, emprestimoFK) VALUES
('EMPRESTADO', 1),
('DEVOLVIDO', 2),
('EMPRESTADO', 3),
('FORA-DO-PRAZO', 4),
('FORA-DO-PRAZO', 5),
('DEVOLVIDO', 6),
('EMPRESTADO', 7),
('FORA-DO-PRAZO', 8),
('EMPRESTADO', 9),
('DEVOLVIDO', 10);

-- 1. Crie da sua mente qualquer consulta usando join sobre o sistema novo;
select l.nomeLivro, a.nomeAutor, e.nomeEditora from livro l join autor a on l.autorFK = a.id 
join editora e on l.editoraFK = e.id;

-- 2. Crie da sua mente qualquer consulta usando subquery no from no sistema novo;
select l.nomeLivro, a.nomeAutor, e.nomeEditora from (select * from livro where genero = 'Romance') l
join autor a on l.autorFK = a.id join editora e on l.editoraFK = e.id;

-- 3. Crie da sua mente qualquer consulta usando subquery no where no sistema novo;
select e.nomeEditora, l.nomeLivro from editora e join livro l on e.id = l.editoraFK
where l.autorFK in (select id from autor where uf = 'SP');

-- 4. Crie a consulta que mostre quantos livros cada autor possui;
select a.nomeAutor, COUNT(l.id) as quantidadeLivros from autor a join livro l on a.id = l.autorFK
group by a.id, a.nomeAutor;

-- 5.Crie a consulta que mostre todos os usuarios e a quantidade que possuem de livros emprestados ainda não entregues
select u.nome as nomeUsuario, COUNT(e.id) as quantidadeLivrosEmprestados from usuarios u
join emprestimo e on u.id = e.usuarioFK join statusEmprestimo se on e.id = se.emprestimoFK
where se.statusEmprestimo = 'EMPRESTADO' group by u.id, u.nome;







